import React from "react";
import { getComunStyle } from "../../css/comun";
const CrearCaso = () => {
  const { root } = getComunStyle();
  return (
    <dib className={root}>
      <span>Estamos creando su caso</span>
    </dib>
  );
};

export default CrearCaso;
